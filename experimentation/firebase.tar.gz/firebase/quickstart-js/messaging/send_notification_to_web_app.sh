#!/bin/sh

while [ 1 ] ; do
	curl -X POST \
		-H "Authorization: key=AAAAC_-M5RQ:APA91bFGcMxQyiFfy0BTPAPk-hLUU1IptF9Vy_NvFXcrebF2f0CC876IHEU0O6cpxjgnKe8ooz2SZIRCIsFmsAyTZHtTyfbfRQ2aljZaSdVRtYJHy3lzBGijVqkr5SmW1HXxV3EMnVe3" \
		-H "Content-Type: application/json" \
		-d "{ \"notification\": { \"body\": \"This is a notification sent at time `date`\"}, \
  			\"to\": \"f9Nd1-PRuWM:APA91bGE7bK85vI8b_QxyRZF41dmYrdk2gdVpoRcZ8ulxHbsEdPX0QPLRuLaZDEUpl79wpz4aR5Wtji6E7rnzJdAKdcNv4WqakpojV2tM75TTVubwZyi5TMmQbmeJaZM4LlzLMeFGDdD\"\
		}"  \
		"https://fcm.googleapis.com/fcm/send"
	echo ; echo Sleeping 5 seconds, then sending another notification...
	sleep 5
done
